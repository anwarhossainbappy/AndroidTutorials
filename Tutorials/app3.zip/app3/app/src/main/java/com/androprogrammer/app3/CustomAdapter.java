package com.androprogrammer.app3;

import android.R.color;
import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

	String value[];
	Activity context;


	public CustomAdapter(Activity context, String [] value) {
		super();
		this.context = context;
		this.value = value;
		
	}

	private class ViewHolder {
		TextView Name;
	}

	public int getCount() {
		return value.length;
	}

	public Object getItem(int position) {
		return value[position];
	}

	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		
		LayoutInflater inflater = context.getLayoutInflater();

		if (convertView == null) {
			convertView = inflater.inflate(R.layout.list_row, null);
			holder = new ViewHolder();

			holder.Name = (TextView) convertView
					.findViewById(R.id.textview1);
			//for alternative layout in list view.
//			if ( position % 2 == 0)
//		        convertView.setBackgroundResource(R.drawable.item_bg);
//			else
//			{
//				convertView.setBackgroundResource(R.drawable.item_bg2);
//				holder.Name.setTextColor(Color.WHITE);
//			}
			convertView.setTag(holder);
			

		} else {
			
			holder = (ViewHolder) convertView.getTag();
		}
				
		holder.Name.setText(value[position]);
		

		return convertView;

	}
}
