/** Automatically generated file. DO NOT MODIFY */
package learn2crack.listview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}