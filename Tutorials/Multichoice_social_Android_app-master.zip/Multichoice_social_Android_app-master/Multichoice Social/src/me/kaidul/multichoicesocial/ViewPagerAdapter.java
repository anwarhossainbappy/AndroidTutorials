package me.kaidul.multichoicesocial;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {
	
	Fragment fbFragment = new FbPortfolioFragment();
	Fragment youtbFragment = new YutbPortfolioFragment();
	Fragment blogsFragment = new BlogsPortfolioFragment();
	
	public ViewPagerAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		switch (position) {
		case 0:
			return fbFragment;
		case 1:
			return youtbFragment;
		case 2:
			return blogsFragment;
		}
		return null;
	}

	@Override
	public int getCount() {
		return CommonUtils.PAGE_COUNT;
	}

}
