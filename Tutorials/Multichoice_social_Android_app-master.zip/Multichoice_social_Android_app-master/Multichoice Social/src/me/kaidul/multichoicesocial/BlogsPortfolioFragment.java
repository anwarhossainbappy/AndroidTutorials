package me.kaidul.multichoicesocial;

public class BlogsPortfolioFragment extends FetchAndExecute{
	private static final String url = CommonUtils.blogsPortfolioUrl;
	private static final String fileName = CommonUtils.blogsPortfolioFile;

	@Override
	protected String getUrl() {
		return url;
	}

	@Override
	protected String getFileName() {
		return fileName;
	}
}
