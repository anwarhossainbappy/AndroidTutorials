package me.kaidul.multichoicesocial;

public class CommonUtils {
	public static boolean isDebuggable = false;
	public static double latitude = 33.964042;
	public static double longitude = -84.252380;
	public static String sitePrefix = "http://www.multichoicesocial.com/";
	public static String postFix = "/?json=1";
	public static String aboutUsUrl = sitePrefix + "about-us" + postFix;
	public static String facebookUrl = sitePrefix + "facebook-customization" + postFix;
	public static String twitterUrl = sitePrefix + "twitter" + postFix;
	public static String youtubeUrl = sitePrefix + "youtube" + postFix;
	public static String mobileSocialMediaUrl = sitePrefix + "mobile-social-media" + postFix;
	public static String marketingBlogsUrl = sitePrefix + "marketing-blogs" + postFix;
	public static String analyticsUrl = sitePrefix + "analytics" + postFix;
	public static String reputationManagementUrl = sitePrefix + "online-reputation-management" + postFix;
	public static String contactUsUrl = sitePrefix + "contact-us" + postFix;
	public static String protfolioUrl = sitePrefix + postFix + "&post_type=portfolio-item";
	public static String aboutUsfile = "about_us.txt";
	public static String facebookfile = "facebook.txt";
	public static String twitterfile = "twitter.txt";
	public static String youtubefile = "youyube.txt";
	public static String  mobileAndSocialFile = "mobile_and_social.txt";
	public static String blogFile = "blogs.txt";
	public static String analyticsFile = "analytics.txt";
	public static String reputationManagementFile = "reputation_management.txt";
	public static String fbPortfolioUrl = sitePrefix + "first-hp-portfolio" + postFix;
	public static String yutbPortfolioUrl = sitePrefix + "second-hp-portfolio" + postFix;
	public static String blogsPortfolioUrl = sitePrefix + "third-hp-portfolio" + postFix;
	public static String fbPortfolioFile = "facebook_portfolio.txt";
	public static String yutbPortfolioFile = "youtube_portfolio.txt";
	public static String blogsPortfolioFile = "blogs_portfolio.txt";
	public static int SPLASH_TIME_OUT = 3000;
	public static int PAGE_COUNT = 3;
}
