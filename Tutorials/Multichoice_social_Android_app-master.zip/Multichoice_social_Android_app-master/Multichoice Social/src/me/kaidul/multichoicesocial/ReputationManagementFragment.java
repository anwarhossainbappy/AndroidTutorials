package me.kaidul.multichoicesocial;

public class ReputationManagementFragment extends FetchAndExecute {
	private static final String url = CommonUtils.reputationManagementUrl;
	private static final String fileName = CommonUtils.reputationManagementFile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
