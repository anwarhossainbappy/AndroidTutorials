package me.kaidul.multichoicesocial;

public class BlogsFragment extends FetchAndExecute {
	private static final String url = CommonUtils.marketingBlogsUrl;
	private static final String fileName = CommonUtils.mobileAndSocialFile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
