package me.kaidul.multichoicesocial;

public class YoutubeFragment extends FetchAndExecute {
	private static final String url = CommonUtils.youtubeUrl;
	private static final String fileName = CommonUtils.youtubefile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
