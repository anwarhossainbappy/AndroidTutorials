package me.kaidul.multichoicesocial;

public class FbPortfolioFragment extends FetchAndExecute {
	private static final String url = CommonUtils.fbPortfolioUrl;
	private static final String fileName = CommonUtils.fbPortfolioFile;

	@Override
	protected String getUrl() {
		return url;
	}

	@Override
	protected String getFileName() {
		return fileName;
	}
}
