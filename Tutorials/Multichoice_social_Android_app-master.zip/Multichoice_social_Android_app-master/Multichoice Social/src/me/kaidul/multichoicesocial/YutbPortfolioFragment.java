package me.kaidul.multichoicesocial;

public class YutbPortfolioFragment extends FetchAndExecute {
	private static final String url = CommonUtils.yutbPortfolioUrl;
	private static final String fileName = CommonUtils.yutbPortfolioFile;

	@Override
	protected String getUrl() {
		return url;
	}

	@Override
	protected String getFileName() {
		return fileName;
	}
}
