package me.kaidul.multichoicesocial;

import java.util.HashMap;
import java.util.List;

import com.actionbarsherlock.app.SherlockFragmentActivity;
import com.actionbarsherlock.view.Menu;
import com.actionbarsherlock.view.MenuItem;

import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.Fragment;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.support.v4.view.GravityCompat;

public class MainActivity extends SherlockFragmentActivity {
	DrawerLayout mDrawerLayout;
	ListView mDrawerList;
	ActionBarDrawerToggle mDrawerToggle;
	String[] title;
	HashMap<String, List<String>> listDataChild;
	Fragment findUsFragment = new FindusFragment();
	Fragment aboutUsFragment = new AboutUsFragment();
	Fragment facebookFragment = new FacebookFragment();
	Fragment twitterFragment = new TwitterFragment();
	Fragment youtubeFragment = new YoutubeFragment();
	Fragment mobileAndSocialFragment = new MobileAndSocialMediaFrament();
	Fragment blogsFragment = new BlogsFragment();
	Fragment analyticsFragment = new AnalyticsFragment();
	Fragment reputationFragment = new ReputationManagementFragment();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.drawer_main);
		if (savedInstanceState != null) {
			return;
		}
		// Generate title
		title = getResources().getStringArray(R.array.navigation_drawer);

		// Locate DrawerLayout in drawer_main.xml
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

		mDrawerList = (ListView) findViewById(R.id.left_drawer);

		// Set a custom shadow that overlays the main content when the drawer
		// opens
		mDrawerLayout.setDrawerShadow(R.drawable.drawer_shadow,
				GravityCompat.START);

		// Set the MenuListAdapter to the ListView
		mDrawerList.setAdapter(new ArrayAdapter<String>(this,
				R.layout.drawer_list_item, title));

		// Capture button clicks on side menu
		mDrawerList.setOnItemClickListener(new DrawerItemClickListener());

		// Enable ActionBar app icon to behave as action to toggle nav drawer
		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);

		// ActionBarDrawerToggle ties together the proper interactions
		// between the sliding drawer and the action bar app icon
		mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, R.string.drawer_open,
				R.string.drawer_close) {

			public void onDrawerSlide(View drawerView, float slideOffset) {
				super.onDrawerSlide(drawerView, slideOffset);
				mDrawerLayout.bringChildToFront(drawerView);
				mDrawerLayout.requestLayout();
			}

			public void onDrawerClosed(View view) {
				super.onDrawerClosed(view);
			}

			public void onDrawerOpened(View drawerView) {
				super.onDrawerOpened(drawerView);
			}
		};

		mDrawerLayout.setDrawerListener(mDrawerToggle);

		if (savedInstanceState == null) {
			selectItem(0);
		}
	}

	/**
	 * @param context
	 * @return <code>true</code> if network connection is available otherwise
	 *         <code>false</code>
	 */
	public static void networkAvailabilityNotice(Context context) {
		new AlertDialog.Builder(context)
				.setTitle("Internet Unavailable")
				.setMessage(
						"Please check your network connection or try again later!")
				.setNeutralButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dlg, int sumthin) {
						dlg.cancel();
					}
				}).show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getSupportMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// nothing for now
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		if (item.getItemId() == android.R.id.home) {

			if (mDrawerLayout.isDrawerOpen(mDrawerList)) {
				mDrawerLayout.closeDrawer(mDrawerList);
			} else {
				mDrawerLayout.openDrawer(mDrawerList);
			}
		} else if (item.getItemId() == R.id.call) {

			Intent callIntent = new Intent(Intent.ACTION_CALL);
			callIntent.setData(Uri.parse("tel:"
					+ getResources().getString(R.string.phone_no)));
			startActivity(callIntent);

		} else if (item.getItemId() == R.id.email) {
			Intent contactIntent = new Intent(MainActivity.this,
					ContactFormActivity.class);
			startActivity(contactIntent);
		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	public void setTitle(CharSequence title) {
		getSupportActionBar().setTitle(title);
	}

	// The click listener for ListView in the navigation drawer
	private class DrawerItemClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			selectItem(position);
		}
	}

	private void selectItem(int position) {

		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		Fragment fragmentName = null;
		boolean isPortfolio = false;
		switch (position) {
		case 0:
			fragmentName = aboutUsFragment;
			break;
		case 1:
			fragmentName = facebookFragment;
			break;
		case 2:
			fragmentName = twitterFragment;
			break;
		case 3:
			fragmentName = youtubeFragment;
			break;
		case 4:
			fragmentName = mobileAndSocialFragment;
			break;
		case 5:
			fragmentName = blogsFragment;
			break;
		case 6:
			fragmentName = analyticsFragment;
			break;
		case 7:
			fragmentName = reputationFragment;
			break;
		case 8:
			isPortfolio = true;
			Intent i = new Intent(MainActivity.this, PortfolioActivity.class);
			startActivity(i);
			break;
		case 9:
			fragmentName = findUsFragment;
			break;
		}
		if (isPortfolio) {
			selectItem(0);
			return;
		}
		ft.replace(R.id.content_frame, fragmentName);
		ft.commit();
		mDrawerList.setItemChecked(position, true);
		setTitle(title[position]);
		mDrawerLayout.closeDrawer(mDrawerList);
	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggles
		mDrawerToggle.onConfigurationChanged(newConfig);
	}
}
