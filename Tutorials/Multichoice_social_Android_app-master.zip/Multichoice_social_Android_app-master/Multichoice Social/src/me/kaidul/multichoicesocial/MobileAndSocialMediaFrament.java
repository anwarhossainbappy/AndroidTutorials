package me.kaidul.multichoicesocial;

public class MobileAndSocialMediaFrament extends FetchAndExecute {
	private static final String url = CommonUtils.mobileSocialMediaUrl;
	private static final String fileName = CommonUtils.mobileAndSocialFile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
