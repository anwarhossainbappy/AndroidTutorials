package me.kaidul.multichoicesocial;

public class AboutUsFragment extends FetchAndExecute {
	private static final String url = CommonUtils.aboutUsUrl;
	private static final String fileName = CommonUtils.aboutUsfile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
	
}
