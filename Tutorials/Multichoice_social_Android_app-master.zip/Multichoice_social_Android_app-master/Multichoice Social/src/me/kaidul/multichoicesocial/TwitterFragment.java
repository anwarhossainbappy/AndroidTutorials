package me.kaidul.multichoicesocial;

public class TwitterFragment extends FetchAndExecute {
	private static final String url = CommonUtils.twitterUrl;
	private static final String fileName = CommonUtils.twitterfile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
