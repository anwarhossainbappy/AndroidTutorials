package me.kaidul.multichoicesocial;

public class FacebookFragment extends FetchAndExecute{
	private static final String url = CommonUtils.facebookUrl;
	private static final String fileName = CommonUtils.facebookfile;
	@Override
	protected String getUrl() {
		return url;
	}
	@Override
	protected String getFileName() {
		return fileName;
	}
}
