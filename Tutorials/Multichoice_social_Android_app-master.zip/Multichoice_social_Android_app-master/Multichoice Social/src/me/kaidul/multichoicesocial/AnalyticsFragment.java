package me.kaidul.multichoicesocial;

public class AnalyticsFragment extends FetchAndExecute {
	private static final String url = CommonUtils.analyticsUrl;
	private static final String fileName = CommonUtils.analyticsFile;
	@Override
	protected String getUrl() {
		return url;
	}
	
	@Override
	protected String getFileName() {
		return fileName;
	}
}
