package me.kaidul.multichoicesocial;

import com.actionbarsherlock.app.SherlockActivity;
import com.actionbarsherlock.view.MenuItem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ContactFormActivity extends SherlockActivity {
	Button send;
	EditText name, phoneNo, message;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.contact_form);
		send = (Button) findViewById(R.id.btn_ok);
		name = (EditText) findViewById(R.id.name);
		phoneNo = (EditText) findViewById(R.id.phone_no);
		message = (EditText) findViewById(R.id.message);
		send.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String to = getResources().getString(R.string.mail);
				String subject = getResources().getString(R.string.subject);
				String msg = message.getText().toString();
				Intent mail = new Intent(Intent.ACTION_SEND);
				mail.putExtra(Intent.EXTRA_EMAIL, to);
				mail.putExtra(Intent.EXTRA_SUBJECT, subject);
				mail.putExtra(Intent.EXTRA_TEXT, msg);
				mail.setType("message/rfc822");
				startActivity(Intent.createChooser(mail, "Send Message via:"));
			}
		});
		getSupportActionBar().setHomeButtonEnabled(true);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
}
