package me.kaidul.multichoicesocial;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.apache.commons.io.IOUtils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.widget.Toast;

import com.devspark.progressfragment.SherlockProgressFragment;
import com.google.gson.stream.JsonReader;

@SuppressLint("NewApi")
public class FetchAndExecute extends SherlockProgressFragment {
	private static final String url = null;
	private static final String fileName = null;
	private FetchTask fetchTask = null;
	WebView webView = null;
	View mContentView;

	protected String getUrl() {
		return url;
	}

	protected String getFileName() {
		return fileName;
	}

	@SuppressLint("SetJavaScriptEnabled")
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		mContentView = inflater.inflate(R.layout.wrapper, container, false);
		webView = (WebView) mContentView.findViewById(R.id.wrapper);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setPluginState(PluginState.ON);
		webView.getSettings().setPluginsEnabled(true);
		webView.getSettings().setAllowFileAccess(true);
		webView.setWebChromeClient(new WebChromeClient());
		webView.getSettings().setBuiltInZoomControls(true);
		int currentapiVersion = android.os.Build.VERSION.SDK_INT;
		if (currentapiVersion >= android.os.Build.VERSION_CODES.HONEYCOMB) {
			webView.getSettings().setDisplayZoomControls(false);
		}
		return super.onCreateView(inflater, container, savedInstanceState);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setContentView(mContentView);
//		if (savedInstanceState != null) {
//            webView.restoreState(savedInstanceState);
//            return;
//        }
		setContentShown(false);
		// check whether internet connection is available or not
		ConnectionDetector cd = new ConnectionDetector(getSherlockActivity());
		boolean hasConnection = cd.isConnectingToInternet();
		if (hasConnection) {
			fetchTask = new FetchTask();
			fetchTask.execute();
		} else {
			boolean isFileAvailable = true;
			String data = null;
			FileInputStream fis = null;
			try {
				fis = getSherlockActivity().getApplicationContext()
						.openFileInput(getFileName());
			} catch (FileNotFoundException e) {
				isFileAvailable = false;
				if (CommonUtils.isDebuggable) {
					Log.wtf("FileNotFoundException", "File isn't found!");
				}
			}
			if (isFileAvailable) {
				try {
					data = IOUtils.toString(fis);
				} catch (IOException e) {
					if (CommonUtils.isDebuggable) {
						Log.wtf("problem", "problem with file reading!");
					}
				}
				webView.loadDataWithBaseURL("", data, "text/html", "UTF-8", "");
				setContentShown(true);
				Toast.makeText(getSherlockActivity(),
						"Cached Copy is shown for network unavailablity",
						Toast.LENGTH_SHORT).show();
			} else {
				MainActivity.networkAvailabilityNotice(getSherlockActivity());
			}
		}
	}

	protected class FetchTask extends AsyncTask<Void, Void, String> {

		@Override
		protected String doInBackground(Void... params) {
			InputStreamReader isr = null;
			String data = null;
			try {
				isr = new JSONDownloader().getJSONStringFromUrl(getUrl());
				JsonReader reader = new JsonReader(isr);
				reader.beginObject();
				while (reader.hasNext()) {
					reader.skipValue();
					reader.skipValue();
					reader.skipValue();
					reader.beginObject();
					while (reader.hasNext()) {
						for (int i = 0; i < 14; ++i) {
							reader.skipValue();
						}
						reader.skipValue();
						data = reader.nextString();
						break;
					}
					break;
				}
			} catch (IOException e) {

			}
			writeToFile(data, getFileName());
			return data;
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			webView.setWebChromeClient(new WebChromeClient() {
				public void onProgressChanged(WebView view, int progress) {
					if (progress >= 100) {
						setContentShown(true);
					}
				}
			});
			webView.loadDataWithBaseURL("", result, "text/html", "UTF-8", "");
//			setContentShown(true);
		}

	}

	private void writeToFile(String data, String fileName) {
		Context mContext = getSherlockActivity();
		try {
			OutputStreamWriter outputStreamWriter = new OutputStreamWriter(
					mContext.getApplicationContext().openFileOutput(fileName,
							Context.MODE_PRIVATE));
			outputStreamWriter.write(data);
			outputStreamWriter.close();
		} catch (IOException e) {
			if (CommonUtils.isDebuggable) {
				Log.e("Exception", "File write failed: " + e.toString());
			}
		}
	}
	
	public void myOnKeyDown(int keyCode) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
            webView.goBack();
        }
	}
	
	@Override
	public void onStop() {
		super.onStop();
		if (fetchTask != null
				&& fetchTask.getStatus() != AsyncTask.Status.FINISHED) {
			fetchTask.cancel(true);
		}
	}
}
