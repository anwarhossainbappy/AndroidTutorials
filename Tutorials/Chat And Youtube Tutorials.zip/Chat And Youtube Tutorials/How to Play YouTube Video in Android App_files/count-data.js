var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"<b>{num}<\/b> Comments","one":"<b>1<\/> Comment"}},"counts":[{"id":"http:\/\/www.androidhive.info\/2014\/12\/how-to-play-youtube-video-in-android-app\/","comments":0}]});
}