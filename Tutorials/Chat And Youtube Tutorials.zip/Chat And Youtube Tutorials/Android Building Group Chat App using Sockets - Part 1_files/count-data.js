var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"text":{"and":"and","comments":{"zero":"0 Comments","multiple":"<b>{num}<\/b> Comments","one":"<b>1<\/> Comment"}},"counts":[{"id":"http:\/\/www.androidhive.info\/2014\/10\/android-building-group-chat-app-using-sockets-part-1\/","comments":105}]});
}