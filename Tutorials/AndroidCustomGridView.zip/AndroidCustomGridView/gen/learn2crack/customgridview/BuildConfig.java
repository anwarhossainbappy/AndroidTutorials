/** Automatically generated file. DO NOT MODIFY */
package learn2crack.customgridview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}