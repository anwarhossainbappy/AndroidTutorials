package apt.tutorial;

public interface IPostMonitor {
}